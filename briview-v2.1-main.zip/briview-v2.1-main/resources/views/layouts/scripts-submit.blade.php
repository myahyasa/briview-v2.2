{{-- ===============================================================SCRIPT MASTER VENDOR=============================================================== --}}
<script>
    var form_tambah_data_master_vendor = document.getElementById('form-tambah-data-master-vendor');
    var submit_tambah_data_master_vendor = document.getElementById('submit-tambah-data-master-vendor');

    form_tambah_data_master_vendor.addEventListener('submit', function () {

        submit_tambah_data_master_vendor.setAttribute('disabled', 'disabled');

        submit_tambah_data_master_vendor.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT MASTER VENDOR=============================================================== --}}

{{-- ===============================================================SCRIPT MASTER KANWIL=============================================================== --}}
<script>
    var form_tambah_data_master_kanwil = document.getElementById('form-tambah-data-master-kanwil');
    var submit_tambah_data_master_kanwil = document.getElementById('submit-tambah-data-master-kanwil');

    form_tambah_data_master_kanwil.addEventListener('submit', function () {

        submit_tambah_data_master_kanwil.setAttribute('disabled', 'disabled');

        submit_tambah_data_master_kanwil.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================ENDSCRIPT MASTER KANWIL=============================================================== --}}

{{-- ===============================================================SCRIPT MASTER KC SUPERVISI=============================================================== --}}
<script>
    var form_tambah_data_kc_supervisi = document.getElementById('form-tambah-data-master-kc-supervisi');
    var submit_tambah_data_master_kc_supervisi = document.getElementById('submit-tambah-data-master-kc-supervisi');

    form_tambah_data_kc_supervisi.addEventListener('submit', function () {

        submit_tambah_data_master_kc_supervisi.setAttribute('disabled', 'disabled');

        submit_tambah_data_master_kc_supervisi.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT MASTER KC SUPERVISI=============================================================== --}}

{{-- ===============================================================SCRIPT MACHINE INFO=============================================================== --}}
<script>
    var form_tambah_data_machine_info = document.getElementById('form-tambah-data-machine-info');
    var submit_tambah_data_machine_info = document.getElementById('submit-tambah-data-machine-info');

    form_tambah_data_machine_info.addEventListener('submit', function () {

        submit_tambah_data_machine_info.setAttribute('disabled', 'disabled');

        submit_tambah_data_machine_info.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT MACHINE INFO=============================================================== --}}

{{-- ===============================================================SCRIPT TID ALLOCATION=============================================================== --}}
<script>
    var form_tambah_data_tid_allocation = document.getElementById('form-tambah-data-tid-allocation');
    var submit_tambah_data_tid_allocation = document.getElementById('submit-tambah-data-tid-allocation');

    form_tambah_data_tid_allocation.addEventListener('submit', function () {

        submit_tambah_data_tid_allocation.setAttribute('disabled', 'disabled');

        submit_tambah_data_tid_allocation.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT TID ALLOCATION=============================================================== --}}

{{-- ===============================================================SCRIPT DIGITAL SIGNAGE=============================================================== --}}
<script>
    var form_tambah_data_digital_signage = document.getElementById('form-tambah-data-digital-signage');
    var submit_tambah_data_digital_signage = document.getElementById('submit-tambah-data-digital-signage');

    form_tambah_data_digital_signage.addEventListener('submit', function () {

        submit_tambah_data_digital_signage.setAttribute('disabled', 'disabled');

        submit_tambah_data_digital_signage.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT DIGITAL SIGNAGE=============================================================== --}}

{{-- ===============================================================SCRIPT CCTV=============================================================== --}}
<script>
    var form_tambah_data_cctv = document.getElementById('form-tambah-data-cctv');
    var submit_tambah_data_cctv = document.getElementById('submit-tambah-data-cctv');

    form_tambah_data_cctv.addEventListener('submit', function () {

        submit_tambah_data_cctv.setAttribute('disabled', 'disabled');

        submit_tambah_data_cctv.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT CCTV=============================================================== --}}

{{-- ===============================================================SCRIPT UPS=============================================================== --}}
<script>
    var form_tambah_data_ups = document.getElementById('form-tambah-data-ups');
    var submit_tambah_data_ups = document.getElementById('submit-tambah-data-ups');

    form_tambah_data_ups.addEventListener('submit', function () {

        submit_tambah_data_ups.setAttribute('disabled', 'disabled');

        submit_tambah_data_ups.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT UPS=============================================================== --}}

{{-- ===============================================================SCRIPT NVR=============================================================== --}}
<script>
    var form_tambah_data_nvr = document.getElementById('form-tambah-data-nvr');
    var submit_tambah_data_nvr = document.getElementById('submit-tambah-data-nvr');

    form_tambah_data_nvr.addEventListener('submit', function () {

        submit_tambah_data_nvr.setAttribute('disabled', 'disabled');

        submit_tambah_data_nvr.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT NVR=============================================================== --}}

{{-- ===============================================================SCRIPT CRO ALLOCATION=============================================================== --}}
<script>
    var form_tambah_data_cro_allocation = document.getElementById('form-tambah-data-cro-allocation');
    var submit_tambah_data_cro_allocation = document.getElementById('submit-tambah-data-cro-allocation');

    form_tambah_data_cro_allocation.addEventListener('submit', function () {

        submit_tambah_data_cro_allocation.setAttribute('disabled', 'disabled');

        submit_tambah_data_cro_allocation.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT CRO ALLOCATION=============================================================== --}}

{{-- ===============================================================SCRIPT MASTER UNIT KERJA=============================================================== --}}
<script>
    var form_tambah_data_master_unit_kerja = document.getElementById('form-tambah-data-master-unit-kerja');
    var submit_tambah_data_master_unit_kerja = document.getElementById('submit-tambah-data-master-unit-kerja');

    form_tambah_data_master_unit_kerja.addEventListener('submit', function () {

        submit_tambah_data_master_unit_kerja.setAttribute('disabled', 'disabled');

        submit_tambah_data_master_unit_kerja.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT MASTER UNIT KERJA=============================================================== --}}


{{-- ===============================================================SCRIPT DETAIL PARAMETER TID=============================================================== --}}
<script>
    var form_tambah_data_detail_parameter_tid = document.getElementById('form-tambah-data-detail-parameter-tid');
    var submit_tambah_data_detail_parameter_tid = document.getElementById('submit-tambah-data-detail-parameter-tid');

    form_tambah_data_detail_parameter_tid.addEventListener('submit', function () {

        submit_tambah_data_detail_parameter_tid.setAttribute('disabled', 'disabled');

        submit_tambah_data_detail_parameter_tid.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT DETAIL PARAMETER TID=============================================================== --}}

{{-- ===============================================================SCRIPT MASTER LOKASI=============================================================== --}}
<script>
    var form_tambah_data_master_lokasi = document.getElementById('form-tambah-data-master-lokasi');
    var submit_tambah_data_master_lokasi = document.getElementById('submit-tambah-data-master-lokasi');

    form_tambah_data_master_lokasi.addEventListener('submit', function () {

        submit_tambah_data_master_lokasi.setAttribute('disabled', 'disabled');

        submit_tambah_data_master_lokasi.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT MASTER LOKASI=============================================================== --}}

{{-- ===============================================================SCRIPT MASTER SERVICE POINT=============================================================== --}}
<script>
    var form_tambah_data_master_service_point = document.getElementById('form-tambah-data-master-service-point');
    var submit_tambah_data_master_service_point = document.getElementById('submit-tambah-data-master-service-point');

    form_tambah_data_master_service_point.addEventListener('submit', function () {

        submit_tambah_data_master_service_point.setAttribute('disabled', 'disabled');

        submit_tambah_data_master_service_point.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT MASTER SERVICE POINT=============================================================== --}}

{{-- ===============================================================SCRIPT MASTER JARAK TEMPUH=============================================================== --}}
<script>
    var form_tambah_data_master_jarak_tempuh = document.getElementById('form-tambah-data-master-jarak-tempuh');
    var submit_tambah_data_master_jarak_tempuh = document.getElementById('submit-tambah-data-master-jarak-tempuh');

    form_tambah_data_master_jarak_tempuh.addEventListener('submit', function () {

        submit_tambah_data_master_jarak_tempuh.setAttribute('disabled', 'disabled');

        submit_tambah_data_master_jarak_tempuh.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT MASTER JARAK TEMPUH=============================================================== --}}

{{-- ===============================================================SCRIPT MASTER SLA PROBLEM=============================================================== --}}
<script>
    var form_tambah_data_master_sla_problem = document.getElementById('form-tambah-data-master-sla-problem');
    var submit_tambah_data_master_sla_problem = document.getElementById('submit-tambah-data-master-sla-problem');

    form_tambah_data_master_sla_problem.addEventListener('submit', function () {

        submit_tambah_data_master_sla_problem.setAttribute('disabled', 'disabled');

        submit_tambah_data_master_sla_problem.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT MASTER SLA PROBLEM=============================================================== --}}

{{-- ===============================================================SCRIPT MASTER SLA PROBLEM=============================================================== --}}
<script>
    var form_tambah_data_mapping_ticket_to_rtl = document.getElementById('form-tambah-data-mapping-ticket-to-rtl');
    var submit_tambah_data_mapping_ticket_to_rtl = document.getElementById('submit-tambah-data-mapping-ticket-to-rtl');

    form_tambah_data_mapping_ticket_to_rtl.addEventListener('submit', function () {

        submit_tambah_data_mapping_ticket_to_rtl.setAttribute('disabled', 'disabled');

        submit_tambah_data_mapping_ticket_to_rtl.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT MASTER SLA PROBLEM=============================================================== --}}

{{-- ===============================================================SCRIPT MASTER SLA PROBLEM=============================================================== --}}
<script>
    var form_tambah_data_sla_tid = document.getElementById('form-tambah-data-sla-tid');
    var submit_tambah_data_sla_tid = document.getElementById('submit-tambah-data-sla-tid');

    form_tambah_data_sla_tid.addEventListener('submit', function () {

        submit_tambah_data_sla_tid.setAttribute('disabled', 'disabled');

        submit_tambah_data_sla_tid.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT MASTER SLA PROBLEM=============================================================== --}}

{{-- ===============================================================SCRIPT MASTER SLA PROBLEM=============================================================== --}}
<script>
    var form_tambah_data_target_performance = document.getElementById('form-tambah-data-target-performance');
    var submit_tambah_data_target_performance = document.getElementById('submit-tambah-data-target-performance');

    form_tambah_data_target_performance.addEventListener('submit', function () {

        submit_tambah_data_target_performance.setAttribute('disabled', 'disabled');

        submit_tambah_data_target_performance.value = 'Tunggu...';


    }, false);

</script>
{{-- ===============================================================END SCRIPT MASTER SLA PROBLEM=============================================================== --}}
