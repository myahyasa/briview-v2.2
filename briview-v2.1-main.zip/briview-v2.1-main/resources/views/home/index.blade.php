{{-- extends app.blade.php --}}
@extends('layouts.app')
@section('content')
<div class="layout-px-spacing">

    <div class="row layout-top-spacing">
        <h2>Selamat Datang,</h2>

    </div>

</div>

@endsection
